﻿CREATE TABLE [dbo].[LoginDatabase]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [USER] NCHAR(10) NULL, 
    [PASSWORD] NCHAR(10) NULL
)
