﻿
UPDATE studentData_Chris
SET [Class AVG] = (Exam1+Exam2*+Exam3+Exam4)/4




SELECT * FROM studentData_Chris
WHERE Id IS NOT NULL