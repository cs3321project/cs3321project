﻿Public Class Student_Main
    Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.StudentData_ChrisBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    End Sub

    Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click_1(sender As Object, e As EventArgs)
        Me.Validate()
        Me.StudentData_ChrisBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    End Sub

    Private Sub Student_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Normal
        'TODO: This line of code loads data into the 'StudentData_ChrisDataSet.studentData_Chris' table. You can move, or remove it, as needed.
        Me.StudentData_ChrisTableAdapter.Fill(Me.StudentData_ChrisDataSet.studentData_Chris)

    End Sub
End Class