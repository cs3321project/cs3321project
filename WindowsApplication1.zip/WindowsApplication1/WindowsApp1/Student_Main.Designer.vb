﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Student_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Student_NameLabel As System.Windows.Forms.Label
        Dim Exam1Label As System.Windows.Forms.Label
        Dim Exam2Label As System.Windows.Forms.Label
        Dim Exam3Label As System.Windows.Forms.Label
        Dim Class_AVGLabel As System.Windows.Forms.Label
        Dim CoursesLabel As System.Windows.Forms.Label
        Dim GPALabel As System.Windows.Forms.Label
        Dim Student_IDLabel As System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button()
        Me.StudentData_ChrisDataSet = New WindowsApp1.StudentData_ChrisDataSet()
        Me.StudentData_ChrisBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentData_ChrisTableAdapter = New WindowsApp1.StudentData_ChrisDataSetTableAdapters.studentData_ChrisTableAdapter()
        Me.TableAdapterManager = New WindowsApp1.StudentData_ChrisDataSetTableAdapters.TableAdapterManager()
        Me.Student_NameTextBox = New System.Windows.Forms.TextBox()
        Me.Exam1TextBox = New System.Windows.Forms.TextBox()
        Me.Exam2TextBox = New System.Windows.Forms.TextBox()
        Me.Exam3TextBox = New System.Windows.Forms.TextBox()
        Me.Class_AVGTextBox = New System.Windows.Forms.TextBox()
        Me.GPATextBox = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Student_IDTextBox = New System.Windows.Forms.TextBox()
        Student_NameLabel = New System.Windows.Forms.Label()
        Exam1Label = New System.Windows.Forms.Label()
        Exam2Label = New System.Windows.Forms.Label()
        Exam3Label = New System.Windows.Forms.Label()
        Class_AVGLabel = New System.Windows.Forms.Label()
        CoursesLabel = New System.Windows.Forms.Label()
        GPALabel = New System.Windows.Forms.Label()
        Student_IDLabel = New System.Windows.Forms.Label()
        CType(Me.StudentData_ChrisDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentData_ChrisBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Student_NameLabel
        '
        Student_NameLabel.AutoSize = True
        Student_NameLabel.Location = New System.Drawing.Point(300, 40)
        Student_NameLabel.Name = "Student_NameLabel"
        Student_NameLabel.Size = New System.Drawing.Size(76, 13)
        Student_NameLabel.TabIndex = 4
        Student_NameLabel.Text = "student Name:"
        '
        'Exam1Label
        '
        Exam1Label.AutoSize = True
        Exam1Label.Location = New System.Drawing.Point(17, 145)
        Exam1Label.Name = "Exam1Label"
        Exam1Label.Size = New System.Drawing.Size(42, 13)
        Exam1Label.TabIndex = 6
        Exam1Label.Text = "Exam1:"
        '
        'Exam2Label
        '
        Exam2Label.AutoSize = True
        Exam2Label.Location = New System.Drawing.Point(17, 171)
        Exam2Label.Name = "Exam2Label"
        Exam2Label.Size = New System.Drawing.Size(42, 13)
        Exam2Label.TabIndex = 8
        Exam2Label.Text = "Exam2:"
        '
        'Exam3Label
        '
        Exam3Label.AutoSize = True
        Exam3Label.Location = New System.Drawing.Point(17, 197)
        Exam3Label.Name = "Exam3Label"
        Exam3Label.Size = New System.Drawing.Size(42, 13)
        Exam3Label.TabIndex = 10
        Exam3Label.Text = "Exam3:"
        '
        'Class_AVGLabel
        '
        Class_AVGLabel.AutoSize = True
        Class_AVGLabel.Location = New System.Drawing.Point(17, 227)
        Class_AVGLabel.Name = "Class_AVGLabel"
        Class_AVGLabel.Size = New System.Drawing.Size(60, 13)
        Class_AVGLabel.TabIndex = 12
        Class_AVGLabel.Text = "Class AVG:"
        '
        'CoursesLabel
        '
        CoursesLabel.AutoSize = True
        CoursesLabel.Location = New System.Drawing.Point(17, 96)
        CoursesLabel.Name = "CoursesLabel"
        CoursesLabel.Size = New System.Drawing.Size(43, 13)
        CoursesLabel.TabIndex = 14
        CoursesLabel.Text = "Course:"
        '
        'GPALabel
        '
        GPALabel.AutoSize = True
        GPALabel.Location = New System.Drawing.Point(17, 279)
        GPALabel.Name = "GPALabel"
        GPALabel.Size = New System.Drawing.Size(32, 13)
        GPALabel.TabIndex = 16
        GPALabel.Text = "GPA:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(49, 385)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(137, 39)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'StudentData_ChrisDataSet
        '
        Me.StudentData_ChrisDataSet.DataSetName = "StudentData_ChrisDataSet"
        Me.StudentData_ChrisDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StudentData_ChrisBindingSource
        '
        Me.StudentData_ChrisBindingSource.DataMember = "studentData_Chris"
        Me.StudentData_ChrisBindingSource.DataSource = Me.StudentData_ChrisDataSet
        '
        'StudentData_ChrisTableAdapter
        '
        Me.StudentData_ChrisTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.studentData_ChrisTableAdapter = Me.StudentData_ChrisTableAdapter
        Me.TableAdapterManager.UpdateOrder = WindowsApp1.StudentData_ChrisDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Student_NameTextBox
        '
        Me.Student_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "student_Name", True))
        Me.Student_NameTextBox.Location = New System.Drawing.Point(382, 37)
        Me.Student_NameTextBox.Name = "Student_NameTextBox"
        Me.Student_NameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Student_NameTextBox.TabIndex = 5
        '
        'Exam1TextBox
        '
        Me.Exam1TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Exam1", True))
        Me.Exam1TextBox.Location = New System.Drawing.Point(99, 142)
        Me.Exam1TextBox.Name = "Exam1TextBox"
        Me.Exam1TextBox.Size = New System.Drawing.Size(100, 20)
        Me.Exam1TextBox.TabIndex = 7
        '
        'Exam2TextBox
        '
        Me.Exam2TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Exam2", True))
        Me.Exam2TextBox.Location = New System.Drawing.Point(99, 168)
        Me.Exam2TextBox.Name = "Exam2TextBox"
        Me.Exam2TextBox.Size = New System.Drawing.Size(100, 20)
        Me.Exam2TextBox.TabIndex = 9
        '
        'Exam3TextBox
        '
        Me.Exam3TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Exam3", True))
        Me.Exam3TextBox.Location = New System.Drawing.Point(99, 194)
        Me.Exam3TextBox.Name = "Exam3TextBox"
        Me.Exam3TextBox.Size = New System.Drawing.Size(100, 20)
        Me.Exam3TextBox.TabIndex = 11
        '
        'Class_AVGTextBox
        '
        Me.Class_AVGTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Class AVG", True))
        Me.Class_AVGTextBox.Location = New System.Drawing.Point(99, 224)
        Me.Class_AVGTextBox.Name = "Class_AVGTextBox"
        Me.Class_AVGTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Class_AVGTextBox.TabIndex = 13
        '
        'GPATextBox
        '
        Me.GPATextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "GPA", True))
        Me.GPATextBox.Location = New System.Drawing.Point(99, 276)
        Me.GPATextBox.Name = "GPATextBox"
        Me.GPATextBox.Size = New System.Drawing.Size(100, 20)
        Me.GPATextBox.TabIndex = 17
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.StudentData_ChrisBindingSource
        Me.ComboBox1.DisplayMember = "Courses"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(99, 88)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(125, 21)
        Me.ComboBox1.TabIndex = 18
        '
        'Student_IDLabel
        '
        Student_IDLabel.AutoSize = True
        Student_IDLabel.Location = New System.Drawing.Point(18, 44)
        Student_IDLabel.Name = "Student_IDLabel"
        Student_IDLabel.Size = New System.Drawing.Size(59, 13)
        Student_IDLabel.TabIndex = 18
        Student_IDLabel.Text = "student ID:"
        '
        'Student_IDTextBox
        '
        Me.Student_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "student_ID", True))
        Me.Student_IDTextBox.Location = New System.Drawing.Point(99, 41)
        Me.Student_IDTextBox.Name = "Student_IDTextBox"
        Me.Student_IDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Student_IDTextBox.TabIndex = 19
        '
        'Student_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Student_IDLabel)
        Me.Controls.Add(Me.Student_IDTextBox)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Student_NameLabel)
        Me.Controls.Add(Me.Student_NameTextBox)
        Me.Controls.Add(Exam1Label)
        Me.Controls.Add(Me.Exam1TextBox)
        Me.Controls.Add(Exam2Label)
        Me.Controls.Add(Me.Exam2TextBox)
        Me.Controls.Add(Exam3Label)
        Me.Controls.Add(Me.Exam3TextBox)
        Me.Controls.Add(Class_AVGLabel)
        Me.Controls.Add(Me.Class_AVGTextBox)
        Me.Controls.Add(CoursesLabel)
        Me.Controls.Add(GPALabel)
        Me.Controls.Add(Me.GPATextBox)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Student_Main"
        Me.Text = "Student_Main"
        CType(Me.StudentData_ChrisDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentData_ChrisBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents StudentData_ChrisDataSet As StudentData_ChrisDataSet
    Friend WithEvents StudentData_ChrisBindingSource As BindingSource
    Friend WithEvents StudentData_ChrisTableAdapter As StudentData_ChrisDataSetTableAdapters.studentData_ChrisTableAdapter
    Friend WithEvents TableAdapterManager As StudentData_ChrisDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Student_NameTextBox As TextBox
    Friend WithEvents Exam1TextBox As TextBox
    Friend WithEvents Exam2TextBox As TextBox
    Friend WithEvents Exam3TextBox As TextBox
    Friend WithEvents Class_AVGTextBox As TextBox
    Friend WithEvents GPATextBox As TextBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Student_IDTextBox As TextBox
End Class
