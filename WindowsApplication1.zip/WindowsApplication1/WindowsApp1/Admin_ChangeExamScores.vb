﻿Public Class Admin_ChangeExamScores
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub

    Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.StudentData_ChrisBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    End Sub

    Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click_1(sender As Object, e As EventArgs) Handles StudentData_ChrisBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.StudentData_ChrisBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    End Sub

    Private Sub Admin_ChangeExamScores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)
        Me.WindowState = FormWindowState.Normal
        'TODO: This line of code loads data into the 'StudentData_ChrisDataSet.studentData_Chris' table. You can move, or remove it, as needed.
        Me.StudentData_ChrisTableAdapter.Fill(Me.StudentData_ChrisDataSet.studentData_Chris)

    End Sub

    Private Sub StudentData_ChrisBindingNavigator_RefreshItems(sender As Object, e As EventArgs) Handles StudentData_ChrisBindingNavigator.RefreshItems

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
End Class