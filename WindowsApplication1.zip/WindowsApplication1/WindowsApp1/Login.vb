﻿Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim form As New Admin_Main
        Dim form2 As New Student_Main
        Dim valid As Boolean = False
        'Dim studentUser As String = "student" 'change later /NOT WORKING
        'Dim adminUser As String = "admin"
        'Dim studentPass As String = "pass"
        'Dim adminPass As String = "pass" 

        If (TextBox1.Text = "test" And TextBox2.Text = "test") Then
            MsgBox("You are now logged in as a student", MsgBoxStyle.Information, "Welcome")
            form2.ShowDialog()
        Else
            If (TextBox1.Text = "test2" And TextBox2.Text = "test2") Then
                MsgBox("You are now logged in as Admin", MsgBoxStyle.Information, "Welcome")
                form.ShowDialog()
            Else
                If TextBox1.Text = "" And TextBox2.Text = "" Then
                    MsgBox("No Username and/or Password Found!", MsgBoxStyle.Critical, "Error")
                Else
                    If TextBox1.Text = "" Then
                        MsgBox("No username found", MsgBoxStyle.Critical, "Error")
                    Else
                        If TextBox2.Text = "" Then

                            MsgBox("No Password Found", MsgBoxStyle.Critical, "Error")
                        Else
                            MsgBox("Invalid Username And/Or Password !", MsgBoxStyle.Critical, "Error")
                        End If
                    End If
                End If
            End If
        End If


    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
