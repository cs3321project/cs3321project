﻿Public Class Admin_ViewStudentData
    Private Sub Admin_ViewStudentData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Normal
        'TODO: This line of code loads data into the 'StudentData_ChrisDataSet.studentData_Chris' table. You can move, or remove it, as needed.
        Me.StudentData_ChrisTableAdapter.Fill(Me.StudentData_ChrisDataSet.studentData_Chris)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub

    Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.StudentData_ChrisBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    End Sub
End Class