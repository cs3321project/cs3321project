﻿Public Class Admin_ViewStudentData
    Private Sub Admin_ViewStudentData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Normal
        'TODO: This line of code loads data into the 'StudentData_ChrisDataSet.studentData_Chris' table. You can move, or remove it, as needed.
        Me.StudentData_ChrisTableAdapter.Fill(Me.StudentData_ChrisDataSet.studentData_Chris)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub

    'Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
    'Me.Validate()
    'Me.StudentData_ChrisBindingSource.EndEdit()
    'Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    'End Sub

    Private Sub SaveBtn_Click(sender As Object, e As EventArgs) Handles SaveBtn.Click

    End Sub

    Private Sub BindingNavigator1_RefreshItems(sender As Object, e As EventArgs) Handles BindingNavigator1.RefreshItems

    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.StudentData_ChrisTableAdapter.FillBy(Me.StudentData_ChrisDataSet.studentData_Chris)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub StudentData_ChrisDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub
End Class