﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Admin_ChangeExamScores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Student_NameLabel As System.Windows.Forms.Label
        Dim Exam1Label As System.Windows.Forms.Label
        Dim Exam2Label As System.Windows.Forms.Label
        Dim Exam3Label As System.Windows.Forms.Label
        Dim CoursesLabel As System.Windows.Forms.Label
        Dim GPALabel As System.Windows.Forms.Label
        Dim IdLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_ChangeExamScores))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.StudentData_ChrisDataSet = New WindowsApp1.StudentData_ChrisDataSet()
        Me.StudentData_ChrisBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentData_ChrisTableAdapter = New WindowsApp1.StudentData_ChrisDataSetTableAdapters.studentData_ChrisTableAdapter()
        Me.TableAdapterManager = New WindowsApp1.StudentData_ChrisDataSetTableAdapters.TableAdapterManager()
        Me.StudentData_ChrisBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.StudentData_ChrisBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Student_NameTextBox = New System.Windows.Forms.TextBox()
        Me.Exam2TextBox = New System.Windows.Forms.TextBox()
        Me.Exam3TextBox = New System.Windows.Forms.TextBox()
        Me.GPATextBox = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Student_NameLabel = New System.Windows.Forms.Label()
        Exam1Label = New System.Windows.Forms.Label()
        Exam2Label = New System.Windows.Forms.Label()
        Exam3Label = New System.Windows.Forms.Label()
        CoursesLabel = New System.Windows.Forms.Label()
        GPALabel = New System.Windows.Forms.Label()
        IdLabel = New System.Windows.Forms.Label()
        CType(Me.StudentData_ChrisDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentData_ChrisBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentData_ChrisBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StudentData_ChrisBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'Student_NameLabel
        '
        Student_NameLabel.AutoSize = True
        Student_NameLabel.Location = New System.Drawing.Point(2, 123)
        Student_NameLabel.Name = "Student_NameLabel"
        Student_NameLabel.Size = New System.Drawing.Size(76, 13)
        Student_NameLabel.TabIndex = 4
        Student_NameLabel.Text = "student Name:"
        '
        'Exam1Label
        '
        Exam1Label.AutoSize = True
        Exam1Label.Location = New System.Drawing.Point(307, 50)
        Exam1Label.Name = "Exam1Label"
        Exam1Label.Size = New System.Drawing.Size(42, 13)
        Exam1Label.TabIndex = 6
        Exam1Label.Text = "Exam1:"
        '
        'Exam2Label
        '
        Exam2Label.AutoSize = True
        Exam2Label.Location = New System.Drawing.Point(425, 47)
        Exam2Label.Name = "Exam2Label"
        Exam2Label.Size = New System.Drawing.Size(42, 13)
        Exam2Label.TabIndex = 8
        Exam2Label.Text = "Exam2:"
        '
        'Exam3Label
        '
        Exam3Label.AutoSize = True
        Exam3Label.Location = New System.Drawing.Point(566, 54)
        Exam3Label.Name = "Exam3Label"
        Exam3Label.Size = New System.Drawing.Size(42, 13)
        Exam3Label.TabIndex = 10
        Exam3Label.Text = "Exam3:"
        '
        'CoursesLabel
        '
        CoursesLabel.AutoSize = True
        CoursesLabel.Location = New System.Drawing.Point(2, 85)
        CoursesLabel.Name = "CoursesLabel"
        CoursesLabel.Size = New System.Drawing.Size(48, 13)
        CoursesLabel.TabIndex = 14
        CoursesLabel.Text = "Courses:"
        '
        'GPALabel
        '
        GPALabel.AutoSize = True
        GPALabel.Location = New System.Drawing.Point(307, 165)
        GPALabel.Name = "GPALabel"
        GPALabel.Size = New System.Drawing.Size(32, 13)
        GPALabel.TabIndex = 16
        GPALabel.Text = "GPA:"
        '
        'IdLabel
        '
        IdLabel.AutoSize = True
        IdLabel.Location = New System.Drawing.Point(12, 47)
        IdLabel.Name = "IdLabel"
        IdLabel.Size = New System.Drawing.Size(19, 13)
        IdLabel.TabIndex = 19
        IdLabel.Text = "Id:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(121, 385)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(137, 39)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'StudentData_ChrisDataSet
        '
        Me.StudentData_ChrisDataSet.DataSetName = "StudentData_ChrisDataSet"
        Me.StudentData_ChrisDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StudentData_ChrisBindingSource
        '
        Me.StudentData_ChrisBindingSource.DataMember = "studentData_Chris"
        Me.StudentData_ChrisBindingSource.DataSource = Me.StudentData_ChrisDataSet
        '
        'StudentData_ChrisTableAdapter
        '
        Me.StudentData_ChrisTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.studentData_ChrisTableAdapter = Me.StudentData_ChrisTableAdapter
        Me.TableAdapterManager.UpdateOrder = WindowsApp1.StudentData_ChrisDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'StudentData_ChrisBindingNavigator
        '
        Me.StudentData_ChrisBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.StudentData_ChrisBindingNavigator.BindingSource = Me.StudentData_ChrisBindingSource
        Me.StudentData_ChrisBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.StudentData_ChrisBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.StudentData_ChrisBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.StudentData_ChrisBindingNavigatorSaveItem})
        Me.StudentData_ChrisBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.StudentData_ChrisBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.StudentData_ChrisBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.StudentData_ChrisBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.StudentData_ChrisBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.StudentData_ChrisBindingNavigator.Name = "StudentData_ChrisBindingNavigator"
        Me.StudentData_ChrisBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.StudentData_ChrisBindingNavigator.Size = New System.Drawing.Size(800, 25)
        Me.StudentData_ChrisBindingNavigator.TabIndex = 1
        Me.StudentData_ChrisBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'StudentData_ChrisBindingNavigatorSaveItem
        '
        Me.StudentData_ChrisBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.StudentData_ChrisBindingNavigatorSaveItem.Image = CType(resources.GetObject("StudentData_ChrisBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.StudentData_ChrisBindingNavigatorSaveItem.Name = "StudentData_ChrisBindingNavigatorSaveItem"
        Me.StudentData_ChrisBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.StudentData_ChrisBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Student_NameTextBox
        '
        Me.Student_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "student_Name", True))
        Me.Student_NameTextBox.Location = New System.Drawing.Point(98, 120)
        Me.Student_NameTextBox.Name = "Student_NameTextBox"
        Me.Student_NameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Student_NameTextBox.TabIndex = 5
        '
        'Exam2TextBox
        '
        Me.Exam2TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Exam2", True))
        Me.Exam2TextBox.Location = New System.Drawing.Point(310, 78)
        Me.Exam2TextBox.Name = "Exam2TextBox"
        Me.Exam2TextBox.Size = New System.Drawing.Size(60, 20)
        Me.Exam2TextBox.TabIndex = 9
        '
        'Exam3TextBox
        '
        Me.Exam3TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Exam3", True))
        Me.Exam3TextBox.Location = New System.Drawing.Point(418, 78)
        Me.Exam3TextBox.Name = "Exam3TextBox"
        Me.Exam3TextBox.Size = New System.Drawing.Size(71, 20)
        Me.Exam3TextBox.TabIndex = 11
        '
        'GPATextBox
        '
        Me.GPATextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "GPA", True))
        Me.GPATextBox.Location = New System.Drawing.Point(389, 162)
        Me.GPATextBox.Name = "GPATextBox"
        Me.GPATextBox.Size = New System.Drawing.Size(100, 20)
        Me.GPATextBox.TabIndex = 17
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(385, 399)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(147, 39)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "Change"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.DataSource = Me.StudentData_ChrisBindingSource
        Me.ComboBox1.DisplayMember = "Courses"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(98, 77)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 19
        '
        'TextBox1
        '
        Me.TextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentData_ChrisBindingSource, "Exam3", True))
        Me.TextBox1.Location = New System.Drawing.Point(550, 78)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(58, 20)
        Me.TextBox1.TabIndex = 21
        '
        'ComboBox2
        '
        Me.ComboBox2.DataSource = Me.StudentData_ChrisBindingSource
        Me.ComboBox2.DisplayMember = "Id"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(98, 47)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 22
        '
        'Admin_ChangeExamScores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 458)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(IdLabel)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Student_NameLabel)
        Me.Controls.Add(Me.Student_NameTextBox)
        Me.Controls.Add(Exam1Label)
        Me.Controls.Add(Exam2Label)
        Me.Controls.Add(Me.Exam2TextBox)
        Me.Controls.Add(Exam3Label)
        Me.Controls.Add(Me.Exam3TextBox)
        Me.Controls.Add(CoursesLabel)
        Me.Controls.Add(GPALabel)
        Me.Controls.Add(Me.GPATextBox)
        Me.Controls.Add(Me.StudentData_ChrisBindingNavigator)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Admin_ChangeExamScores"
        Me.Text = "Admin_ChangeExamScores"
        CType(Me.StudentData_ChrisDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentData_ChrisBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentData_ChrisBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StudentData_ChrisBindingNavigator.ResumeLayout(False)
        Me.StudentData_ChrisBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents StudentData_ChrisDataSet As StudentData_ChrisDataSet
    Friend WithEvents StudentData_ChrisBindingSource As BindingSource
    Friend WithEvents StudentData_ChrisTableAdapter As StudentData_ChrisDataSetTableAdapters.studentData_ChrisTableAdapter
    Friend WithEvents TableAdapterManager As StudentData_ChrisDataSetTableAdapters.TableAdapterManager
    Friend WithEvents StudentData_ChrisBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents StudentData_ChrisBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents Student_NameTextBox As TextBox
    Friend WithEvents Exam2TextBox As TextBox
    Friend WithEvents Exam3TextBox As TextBox
    Friend WithEvents GPATextBox As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ComboBox2 As ComboBox
End Class
