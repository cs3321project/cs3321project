﻿Public Class AddRemove_Student
    Private Sub StudentData_ChrisBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.StudentData_ChrisBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)

    End Sub

    Private Sub AddRemove_Student_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)
        Me.WindowState = FormWindowState.Normal
        'TODO: This line of code loads data into the 'StudentData_ChrisDataSet.studentData_Chris' table. You can move, or remove it, as needed.
        Me.StudentData_ChrisTableAdapter.Fill(Me.StudentData_ChrisDataSet.studentData_Chris)
        If ComboBox1.Text = Nothing Then
            Try
                StudentData_ChrisBindingSource.AddNew()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            StudentData_ChrisBindingSource.AddNew()
            Student_NameTextBox.Select()
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Select Case MsgBox("Are you sure you want to delete the student?", MsgBoxStyle.YesNo, "Confirmation")
            Case MsgBoxResult.Yes
                Try
                    StudentData_ChrisBindingSource.RemoveCurrent()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
            Case MsgBoxResult.No
                ' do nothing'
        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            StudentData_ChrisBindingSource.MovePrevious()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            StudentData_ChrisBindingSource.MoveNext()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        If Student_NameTextBox.Text = Nothing Then
            Student_NameTextBox.Text = "Unknown"
        End If
        If Exam1TextBox.Text = Nothing Then
            Exam1TextBox.Text = "Unknown"
        End If
        If Exam2TextBox.Text = Nothing Then
            Exam2TextBox.Text = "Unknown"

        End If
        If Exam3TextBox.Text = Nothing Then
            Exam3TextBox.Text = "Unknown"
        End If
        If Class_AVGTextBox.Text = Nothing Then
            Class_AVGTextBox.Text = "Unknown"
        End If
        Try
            Me.Validate()
            Me.StudentData_ChrisBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.StudentData_ChrisDataSet)
            MessageBox.Show("New Student has been added", "Information", MessageBoxButtons.OK)
            StudentData_ChrisBindingSource.AddNew()
            Student_NameTextBox.Select()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub BindingNavigator1_RefreshItems(sender As Object, e As EventArgs) Handles BindingNavigator1.RefreshItems

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub
End Class